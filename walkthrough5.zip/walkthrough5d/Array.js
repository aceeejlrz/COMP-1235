// Describe the fileline
describe('Array', function() {

    // Describe the Function Name (.functionName)
    describe('.pop', function() {
        // Instructions:
        it("remove the item", function() {
            var array = [1, 2, 3];
        });   
    });
    describe('.add', function() {
        // Instructions:
        it("remove the item", function() {
            // code instructions goes here 
        });   
    });
});
